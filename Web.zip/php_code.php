<?php

// Define your secret API key
$apiKey = "1510";

function fetchAndSavePlaylist($url, $folderPath)
{
    // Fetch the M3U file from the URL
    $m3uContent = file_get_contents($url);

    if ($m3uContent === false) {
        throw new Exception("Failed to fetch M3U file from the provided URL.");
    }

    // Parse the M3U file
    $channels = parseM3U($m3uContent);

    // Save each channel's URL in a respective .txt file
    foreach ($channels as $channel) {
        $fileName = $folderPath . '/' . sanitizeFileName($channel['name']) . '.txt';
        $channelUrl = $channel['url'];

        // Save the URL to the file
        file_put_contents($fileName, $channelUrl . PHP_EOL); // Append PHP_EOL for line breaks
    }

    echo "Done. Channels loaded successfully.";
}

function parseM3U($m3uContent)
{
    $lines = explode("\n", $m3uContent);
    $channels = array();

    foreach ($lines as $index => $line) {
        if (strpos($line, '#EXTINF') === 0) {
            $channel = array('group' => '', 'name' => '', 'url' => ''); // Initialize channel with an empty group, name, and URL

            // Extract the group title and name from the '#EXTINF' line
            preg_match('/group-title="([^"]*)".*?,([^"]*)/', $line, $matches);
            $channel['group'] = isset($matches[1]) ? trim($matches[1]) : '';
            $channel['name'] = isset($matches[2]) ? trim($matches[2]) : '';

            // Find the next line with the channel URL
            for ($i = $index + 1; $i < count($lines); $i++) {
                if (strpos($lines[$i], 'http') === 0) {
                    $channel['url'] = trim($lines[$i]);
                    break;
                }
            }

            $channels[] = $channel;
        }
    }

    return $channels;
}

function sanitizeFileName($fileName)
{
    // Replace spaces with underscores and remove other special characters
    return preg_replace('/[^\w\s]/', '', str_replace(' ', '_', $fileName));
}

function isPartialMatch($channelName, $searchTerm)
{
    $channelNameLower = strtolower($channelName);
    $searchTermLower = strtolower($searchTerm);

    $searchWords = explode(' ', $searchTermLower);

    foreach ($searchWords as $word) {
        if (strpos($channelNameLower, $word) !== false) {
            return true;
        }
    }

    return false;
}

?>

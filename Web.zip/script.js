const plyrPlayer = new Plyr("#plyrPlayer", {
    quality: {
        default: 720,
        options: [1080, 720, 480, 360],
        forced: true,
        onChange: (quality) => {
            console.log('Quality changed to', quality);
        },
    },
});

function changeVideo(urlFile) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                var videoURL = xhr.responseText.trim();
                if (videoURL) {
                    updatePlyrPlayer(videoURL);
                } else {
                    console.error('Empty or invalid video URL');
                }
            } else {
                console.error('Failed to load video URL from file');
            }
        }
    };
    xhr.open('GET', urlFile, true);
    xhr.send();
}

function updatePlyrPlayer(videoURL) {
    console.log('Updating Plyr player with new video URL:', videoURL);
    plyrPlayer.source = {
        type: 'video',
        sources: [
            {
                src: videoURL,
                type: 'video/mp4',
            },
        ],
    };
}

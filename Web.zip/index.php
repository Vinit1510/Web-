<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.plyr.io/3.6.4/plyr.css" />
    <link rel="stylesheet" href="https://cdn.plyr.io/3.6.4/plyr.quality.css" />
    <title>V TV</title>
    <link rel="stylesheet" href="css/styles.css" />
    <link rel="stylesheet" href="css/search.css">
</head>

<body>

<video id="plyrPlayer" controls></video>

<form method="post" action="index.php">
    <label for="m3u_url">only for admin:</label>
    <input type="text" id="m3u_url" name="m3u_url" placeholder="https://example.com/playlist.m3u"> <button type="submit">Load</button>
    <br></br>
    <label for="api_key">Key:</label>
    <input type="text" id="api_key" name="api_key" placeholder="Enter your secret key">
    <br>    </br>
    <br><center>
        <label for="channel_search">Search :</label>
        <input type="text" id="channel_search" name="channel_search" placeholder="search channel">
    </center></br>
</form>

<script src="https://cdn.plyr.io/3.6.4/plyr.js"></script>
<script src="https://cdn.plyr.io/3.6.4 /plyr.quality.js"></script>
<script type="text/javascript" src="script.js"></script>

<?php
include 'php_code.php';

$folderPath = 'video_urls';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the API key is correct
    $providedKey = isset($_POST["api_key"]) ? $_POST["api_key"] : '';

    if ($providedKey === $apiKey) {
        try {
            $url = $_POST["m3u_url"];

            if (!empty($url)) {
                if (!is_dir($folderPath)) {
                    mkdir($folderPath, 0777, true);
                }

                fetchAndSavePlaylist($url, $folderPath);
            } else {
                echo "Error: Please provide a valid M3U URL.";
            }
        } catch (Exception $e) {
            echo "Error: " . $e->getMessage();
        }
    } else {
        echo "Error: Invalid key. Access denied.";
    }
}
?>

<?php
if (is_dir($folderPath)) {
    $files = glob($folderPath . '/*.txt');
    $searchTerm = isset($_POST['channel_search']) ? $_POST['channel_search'] : '';
    $buttonCount = 0;

    foreach ($files as $file) {
        $content = file_get_contents($file);
        preg_match('/[^\/]+(?=\.txt$)/', $file, $matches);
        $fileName = isset($matches[0]) ? $matches[0] : '';

        if (empty($searchTerm) || isPartialMatch($fileName, $searchTerm)) {
            echo '<button onclick="changeVideo(\'' . $file . '\')">' . $fileName . '</button>';
            $buttonCount++;

            // Add the ads script after every 7th button
            if ($buttonCount % 7 === 0) {
                echo '<br>'; // Line break before the ads script
                echo '<script type="text/javascript">';
                echo '   atOptions = {';
                echo '       \'key\' : \'7f37829fc2c422f7ae36af07ce2efcb2\',';
                echo '       \'format\' : \'iframe\',';
                echo '       \'height\' : 60,';
                echo '       \'width\' : 468,';
                echo '       \'params\' : {}';
                echo '   };';
                echo '   document.write(\'<scr\' + \'ipt type="text/javascript" src="//seatedsaintinsist.com/7f37829fc2c422f7ae36af07ce2efcb2/invoke.js"></scr\' + \'ipt>\');';
                echo '</script>';
            }
        }
    }
}
?>
</body>
</html>
